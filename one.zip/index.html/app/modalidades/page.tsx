import type { Metadata } from "next";
import Image from "next/image";
import {
  Dumbbell,
  Bike,
  PersonStanding,
  Waves,
  HeartPulse,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { site } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Modalidades",
  description:
    "Conheça as modalidades da One Fitness Academia: musculação, cardio, treino funcional, aulas em grupo e muito mais.",
};

const modalidades = [
  {
    icon: Dumbbell,
    title: "Musculação",
    image: "/images/gym-musculacao.jpg",
    text: "Área completa com equipamentos para todos os grupos musculares, ideal para hipertrofia, força e condicionamento.",
    tag: "Todos os níveis",
  },
  {
    icon: Bike,
    title: "Cardio",
    image: "/images/esteiras.jpg",
    text: "Esteiras Kikos de última geração, com painel digital e sistema de amortecimento para treinos aeróbicos eficientes.",
    tag: "Alta performance",
  },
  {
    icon: PersonStanding,
    title: "Treino Funcional",
    image: "/images/entrada-plantas.jpg",
    text: "Exercícios que trabalham mobilidade, equilíbrio e força funcional, com acompanhamento próximo dos instrutores.",
    tag: "Dinâmico",
  },
];

const outrasModalidades = [
  {
    icon: HeartPulse,
    title: "Avaliação Física",
    text: "Avaliação completa gratuita na matrícula para traçar seu ponto de partida.",
  },
  {
    icon: Users,
    title: "Treino Personalizado",
    text: "Professores disponíveis para montar um treino de acordo com seus objetivos.",
  },
  {
    icon: Waves,
    title: "Alongamento e Mobilidade",
    text: "Espaço dedicado para alongar e cuidar da recuperação muscular.",
  },
];

export default function ModalidadesPage() {
  return (
    <>
      <section className="bg-navy-900 py-20 text-center md:py-28">
        <div className="container-x">
          <span className="eyebrow justify-center text-sky-300">
            Diversidade de treinos
          </span>
          <h1 className="mx-auto mt-4 max-w-2xl text-4xl font-extrabold text-white md:text-5xl">
            Escolha onde suar a camisa
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-navy-200">
            Estrutura completa para você treinar do seu jeito, com equipamentos
            modernos e profissionais sempre por perto.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container-x space-y-16">
          {modalidades.map((mod, index) => (
            <div
              key={mod.title}
              className={`grid items-center gap-10 lg:grid-cols-2 ${
                index % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
              }`}
            >
              <div className="relative h-80 overflow-hidden rounded-2xl shadow-soft">
                <Image src={mod.image} alt={mod.title} fill className="object-cover" />
              </div>
              <div>
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-50">
                  <mod.icon className="h-7 w-7 text-sky-500" />
                </div>
                <span className="mt-4 inline-block rounded-full bg-navy-900 px-3 py-1 text-xs font-semibold text-white">
                  {mod.tag}
                </span>
                <h2 className="mt-3 text-3xl font-extrabold text-navy-900">
                  {mod.title}
                </h2>
                <p className="mt-4 leading-relaxed text-navy-600">{mod.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="section bg-navy-50">
        <div className="container-x">
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow justify-center text-sky-500">
              Também disponível
            </span>
            <h2 className="mt-3 text-3xl font-extrabold text-navy-900 md:text-4xl">
              Suporte completo para o seu treino
            </h2>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-3">
            {outrasModalidades.map((item) => (
              <div key={item.title} className="card p-6 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-sky-50">
                  <item.icon className="h-6 w-6 text-sky-500" />
                </div>
                <h3 className="mt-4 font-bold text-navy-900">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-500">
                  {item.text}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <a href={site.whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button variant="primary" size="lg">
                Agende sua aula experimental
              </Button>
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
