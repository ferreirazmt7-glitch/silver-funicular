import type { Metadata } from "next";
import { Check, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn, site } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Planos e Preços",
  description:
    "Conheça os planos da One Fitness Academia, a partir de R$ 180. Matricule-se e a avaliação física é grátis.",
};

const planos = [
  {
    name: "Mensal",
    price: "180",
    period: "/mês",
    highlight: false,
    features: [
      "Acesso à musculação e cardio",
      "Avaliação física gratuita",
      "Sem taxa de matrícula",
      "Flexibilidade total, sem fidelidade",
    ],
  },
  {
    name: "Trimestral",
    price: "160",
    period: "/mês",
    highlight: true,
    features: [
      "Tudo do plano Mensal",
      "Avaliação física gratuita",
      "Desconto especial no trimestre",
      "Acompanhamento de treino",
      "Prioridade em horários de pico",
    ],
  },
  {
    name: "Anual",
    price: "140",
    period: "/mês",
    highlight: false,
    features: [
      "Tudo do plano Trimestral",
      "Melhor custo-benefício",
      "Congelamento facilitado",
      "Convite para eventos exclusivos",
    ],
  },
];

export default function PlanosPage() {
  return (
    <>
      <section className="bg-navy-900 py-20 text-center md:py-28">
        <div className="container-x">
          <span className="eyebrow justify-center text-sky-300">
            Facilidade de pagamento
          </span>
          <h1 className="mx-auto mt-4 max-w-2xl text-4xl font-extrabold text-white md:text-5xl">
            Planos a partir de R$ 180
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-navy-200">
            Escolha o plano ideal para o seu momento. Matricule-se agora e a
            avaliação física é totalmente grátis.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container-x">
          <div className="grid gap-8 lg:grid-cols-3">
            {planos.map((plano) => (
              <Card
                key={plano.name}
                className={cn(
                  "relative flex flex-col p-2",
                  plano.highlight && "border-2 border-sky-400 shadow-soft lg:-translate-y-4"
                )}
              >
                {plano.highlight && (
                  <Badge
                    variant="accent"
                    className="absolute -top-3 left-1/2 -translate-x-1/2 gap-1"
                  >
                    <Sparkles className="h-3.5 w-3.5" /> Mais escolhido
                  </Badge>
                )}
                <CardContent className="flex flex-1 flex-col pt-8">
                  <h3 className="text-center text-xl font-bold text-navy-900">
                    {plano.name}
                  </h3>
                  <div className="mt-4 flex items-end justify-center gap-1">
                    <span className="text-lg font-semibold text-navy-500">R$</span>
                    <span className="text-5xl font-extrabold text-navy-900">
                      {plano.price}
                    </span>
                    <span className="pb-1 text-sm text-navy-400">{plano.period}</span>
                  </div>

                  <ul className="mt-8 flex-1 space-y-3">
                    {plano.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm text-navy-600">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-sky-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <a
                    href={site.whatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-8"
                  >
                    <Button
                      variant={plano.highlight ? "accent" : "outline"}
                      className="w-full"
                    >
                      Escolher plano
                    </Button>
                  </a>
                </CardContent>
              </Card>
            ))}
          </div>

          <p className="mt-10 text-center text-sm text-navy-400">
            Valores sujeitos a alteração. Fale com nossa equipe pelo WhatsApp
            para condições especiais e formas de pagamento.
          </p>
        </div>
      </section>
    </>
  );
}
