import type { Metadata } from "next";
import { Phone, MapPin, Clock, Instagram } from "lucide-react";
import { ContactForm } from "@/components/contact-form";
import { Accordion } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { site } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Contato",
  description:
    "Entre em contato com a One Fitness Academia. Endereço, telefone e formulário para agendar sua avaliação física gratuita.",
};

const faq = [
  {
    question: "A avaliação física é realmente gratuita?",
    answer:
      "Sim! Ao se matricular na One Fitness Academia, você recebe uma avaliação física completa sem nenhum custo adicional.",
  },
  {
    question: "Preciso agendar horário para treinar?",
    answer:
      "Não é necessário agendamento para musculação e cardio. Você pode treinar no horário que preferir dentro do funcionamento da academia.",
  },
  {
    question: "Quais são as formas de pagamento aceitas?",
    answer:
      "Aceitamos cartão de crédito, débito e Pix. Fale com nossa equipe pelo WhatsApp para conhecer as condições especiais.",
  },
  {
    question: "Existe taxa de matrícula?",
    answer:
      "Consulte nossa equipe sobre as condições vigentes de matrícula, que costumam incluir promoções e planos a partir de R$ 180.",
  },
  {
    question: "Como faço para agendar uma aula experimental?",
    answer:
      "É simples: entre em contato pelo WhatsApp, escolha um horário e venha conhecer nossa estrutura com o acompanhamento de um instrutor.",
  },
];

export default function ContatoPage() {
  return (
    <>
      <section className="bg-navy-900 py-20 text-center md:py-28">
        <div className="container-x">
          <span className="eyebrow justify-center text-sky-300">Fale com a gente</span>
          <h1 className="mx-auto mt-4 max-w-2xl text-4xl font-extrabold text-white md:text-5xl">
            Vamos te ajudar a começar
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-navy-200">
            Tire suas dúvidas, agende uma visita ou solicite informações sobre
            os planos. Estamos por perto para te atender.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container-x grid gap-12 lg:grid-cols-2">
          <div>
            <h2 className="text-2xl font-extrabold text-navy-900">
              Envie sua mensagem
            </h2>
            <p className="mt-2 text-sm text-navy-500">
              Preencha o formulário abaixo e retornaremos o mais breve possível.
            </p>
            <div className="mt-6">
              <ContactForm />
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-extrabold text-navy-900">
              Informações de contato
            </h2>
            <div className="mt-6 space-y-5">
              <a
                href={`tel:+${site.phoneRaw}`}
                className="flex items-start gap-3 rounded-2xl border border-navy-100 bg-white p-5 transition-colors hover:border-sky-300"
              >
                <Phone className="mt-0.5 h-5 w-5 shrink-0 text-sky-500" />
                <div>
                  <p className="font-semibold text-navy-900">Telefone / WhatsApp</p>
                  <p className="text-sm text-navy-500">{site.phoneDisplay}</p>
                </div>
              </a>

              <a
                href={site.mapsLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-3 rounded-2xl border border-navy-100 bg-white p-5 transition-colors hover:border-sky-300"
              >
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-sky-500" />
                <div>
                  <p className="font-semibold text-navy-900">Endereço</p>
                  <p className="text-sm text-navy-500">{site.address}</p>
                </div>
              </a>

              <div className="flex items-start gap-3 rounded-2xl border border-navy-100 bg-white p-5">
                <Clock className="mt-0.5 h-5 w-5 shrink-0 text-sky-500" />
                <div>
                  <p className="font-semibold text-navy-900">Horário de funcionamento</p>
                  {site.hours.map((h) => (
                    <p key={h.day} className="text-sm text-navy-500">
                      {h.day}: {h.time}
                    </p>
                  ))}
                </div>
              </div>

              <a
                href={site.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-3 rounded-2xl border border-navy-100 bg-white p-5 transition-colors hover:border-sky-300"
              >
                <Instagram className="mt-0.5 h-5 w-5 shrink-0 text-sky-500" />
                <div>
                  <p className="font-semibold text-navy-900">Instagram</p>
                  <p className="text-sm text-navy-500">@onefitnessacademia</p>
                </div>
              </a>
            </div>

            <a href={site.whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button variant="accent" className="mt-6 w-full">
                Chamar no WhatsApp agora
              </Button>
            </a>
          </div>
        </div>
      </section>

      <section className="section bg-navy-50">
        <div className="container-x">
          <div className="h-80 overflow-hidden rounded-2xl border border-navy-100 shadow-sm lg:h-[420px]">
            <iframe
              src={site.mapsEmbedUrl}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Localização da One Fitness Academia"
            />
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container-x">
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow justify-center text-sky-500">Dúvidas frequentes</span>
            <h2 className="mt-3 text-3xl font-extrabold text-navy-900 md:text-4xl">
              Tudo o que você precisa saber
            </h2>
          </div>
          <div className="mx-auto mt-10 max-w-3xl">
            <Accordion items={faq} />
          </div>
        </div>
      </section>
    </>
  );
}
