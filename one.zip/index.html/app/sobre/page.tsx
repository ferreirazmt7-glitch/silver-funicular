import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Leaf, Wind, ShieldCheck, Sparkles, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { site } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Sobre a Academia",
  description:
    "Conheça a One Fitness Academia: estrutura completa, ambiente climatizado e equipe pronta para te ajudar a evoluir em Santa Cecília, São Paulo.",
};

const diferenciais = [
  {
    icon: Sparkles,
    title: "Estrutura moderna",
    text: "Equipamentos de musculação e cardio de última geração, sempre em ótimo estado de conservação.",
  },
  {
    icon: Wind,
    title: "Ambiente climatizado",
    text: "Espaço amplo, arejado e agradável para você treinar em qualquer horário do dia.",
  },
  {
    icon: Leaf,
    title: "Design acolhedor",
    text: "Detalhes de decoração natural e iluminação pensada para tornar seu treino mais agradável.",
  },
  {
    icon: ShieldCheck,
    title: "Segurança e limpeza",
    text: "Rotina rigorosa de higienização e equipe atenta para sua segurança durante o treino.",
  },
];

const galeria = [
  { src: "/images/gym-musculacao.jpg", alt: "Área de musculação da One Fitness Academia" },
  { src: "/images/esteiras.jpg", alt: "Esteiras de cardio da One Fitness Academia" },
  { src: "/images/entrada-plantas.jpg", alt: "Entrada com jardim vertical da One Fitness Academia" },
  { src: "/images/fachada.jpg", alt: "Fachada da One Fitness Academia" },
];

export default function SobrePage() {
  return (
    <>
      <section className="relative overflow-hidden bg-navy-900">
        <div className="absolute inset-0">
          <Image
            src="/images/entrada-plantas.jpg"
            alt=""
            fill
            className="object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-navy-900/60 via-navy-900/90 to-navy-900" />
        </div>
        <div className="container-x relative py-20 text-center md:py-28">
          <span className="eyebrow justify-center text-sky-300">Nossa essência</span>
          <h1 className="mx-auto mt-4 max-w-2xl text-4xl font-extrabold text-white md:text-5xl">
            Mais que uma academia, um espaço para você evoluir
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-navy-200">
            A One Fitness Academia nasceu para oferecer um treino completo em
            um ambiente pensado nos mínimos detalhes, do acolhimento na
            entrada aos equipamentos de última geração.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container-x grid gap-12 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="eyebrow text-sky-500">Nossa história</span>
            <h2 className="mt-3 text-3xl font-extrabold text-navy-900 md:text-4xl">
              Stay fit &amp; healthy é o nosso compromisso
            </h2>
            <p className="mt-4 leading-relaxed text-navy-600">
              Localizada na Santa Cecília, em São Paulo, a One Fitness
              Academia foi criada para ser o ponto de encontro de quem busca
              qualidade de vida através do movimento. Aqui você encontra
              musculação completa, área de cardio equipada com esteiras de
              última geração e uma equipe sempre disponível para te ajudar a
              atingir seus objetivos.
            </p>
            <p className="mt-4 leading-relaxed text-navy-600">
              Cuidamos de cada detalhe do espaço, do jardim vertical na
              entrada à climatização do salão, para que seu treino seja
              sempre uma experiência agradável, do início ao fim.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a href={site.whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button variant="primary">Agendar visita</Button>
              </a>
              <Link href="/modalidades">
                <Button variant="outline">
                  Conhecer modalidades <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative h-96 overflow-hidden rounded-2xl shadow-soft">
            <Image
              src="/images/gym-musculacao.jpg"
              alt="Interior da área de musculação da One Fitness Academia"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section className="section bg-navy-50">
        <div className="container-x">
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow justify-center text-sky-500">Diferenciais</span>
            <h2 className="mt-3 text-3xl font-extrabold text-navy-900 md:text-4xl">
              Por que treinar na One
            </h2>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {diferenciais.map((item) => (
              <div key={item.title} className="card p-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sky-50">
                  <item.icon className="h-6 w-6 text-sky-500" />
                </div>
                <h3 className="mt-4 font-bold text-navy-900">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-500">
                  {item.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container-x">
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow justify-center text-sky-500">Galeria</span>
            <h2 className="mt-3 text-3xl font-extrabold text-navy-900 md:text-4xl">
              Nossos espaços
            </h2>
          </div>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {galeria.map((img) => (
              <div
                key={img.src}
                className="relative h-64 overflow-hidden rounded-2xl shadow-sm"
              >
                <Image
                  src={img.src}
                  alt={img.alt}
                  fill
                  className="object-cover transition-transform duration-500 hover:scale-105"
                />
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
