import type { Metadata } from "next";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ReviewsSection } from "@/components/reviews-section";
import { site } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Avaliações",
  description:
    "Veja o que os alunos da One Fitness Academia dizem sobre a estrutura, atendimento e resultados.",
};

export default function AvaliacoesPage() {
  return (
    <>
      <section className="bg-navy-900 py-20 text-center md:py-28">
        <div className="container-x">
          <span className="eyebrow justify-center text-sky-300">
            Depoimentos reais
          </span>
          <h1 className="mx-auto mt-4 max-w-2xl text-4xl font-extrabold text-white md:text-5xl">
            O que nossos alunos dizem
          </h1>
          <div className="mt-6 flex items-center justify-center gap-2">
            <div className="flex gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-sky-400 text-sky-400" />
              ))}
            </div>
            <span className="font-semibold text-navy-200">
              Avaliações verificadas no Google
            </span>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container-x">
          <ReviewsSection />

          <div className="mt-16 rounded-3xl bg-navy-50 p-10 text-center md:p-14">
            <h2 className="text-2xl font-extrabold text-navy-900 md:text-3xl">
              Já treina com a gente? Deixe sua avaliação
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-navy-500">
              Sua opinião ajuda outras pessoas a conhecerem a One Fitness
              Academia e nos ajuda a melhorar cada vez mais.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-4">
              <a href={site.mapsLink} target="_blank" rel="noopener noreferrer">
                <Button variant="primary">Avaliar no Google</Button>
              </a>
              <a href={site.whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button variant="outline">Falar com a gente</Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
